# coding=utf-8
import unittest
from selenium import webdriver
from page.BasePage import BasePage
from time import sleep
from page.PlateJump_Page import *
from page.Search_Page import Search_Page
import config

class Test_Search(unittest.TestCase):
    """
            页面跳转模块case
    """

    def setUp(self):
        self.driver = webdriver.Chrome()
        # self.driver =config.browser
        self.driver.implicitly_wait(10)
        # self.url = "http://sohu.com"
        self.url = config.test_url

    # 用例执行体


    def tearDown(self):
        self.driver.quit()

if __name__ == "__main__":
    unittest.main()