# coding=utf-8
import unittest
from selenium import webdriver
from page.BasePage import BasePage
from time import sleep
from page.PlateJump_Page import *
import config
class Test_PlantJump(unittest.TestCase):
    """
            页面跳转模块case
    """

    def setUp(self):
        self.driver = webdriver.Chrome()
        # self.driver =config.browser
        self.driver.implicitly_wait(10)
        # self.url = "http://sohu.com"
        self.url = config.test_url

    # 用例执行体
    def test_open_news(self):
        base_page = BasePage(self.driver, self.url)
        # 调用打开页面组件
        base_page.open()
        base_page.click(PlateJumpPage.news)
        sleep(5)
        base_page.switch_to_window_now()
        # self.assertEqual(self.driver.title, '搜狐新闻-搜狐')
        self.assertEqual(self.driver.title, '错误的运行')

    def tearDown(self):
        self.driver.quit()

if __name__ == "__main__":
    unittest.main()