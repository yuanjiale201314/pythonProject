# coding=utf-8
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
from time import sleep
import xlrd2
from selenium.webdriver.common.keys import Keys

class BasePage(object):
    """
    BasePage封装所有页面都公用的方法，例如driver, url ,FindElement等
    """

    # 初始化driver、url
    # 实例化BasePage类时，最先执行的就是__init__方法，该方法的入参，其实就是BasePage类的入参。
    # __init__方法不能有返回值，只能返回None
    # self只实例本身，相较于类Page而言。
    def __init__(self, selenium_driver, base_url):
        self.driver = selenium_driver
        self.base_url = base_url
        self.elements = {}

    # 通过title断言进入的页面是否正确。
    # 使用title获取当前窗口title，检查输入的title是否在当前title中，返回比较结果（True 或 False）
    def on_page(self, pagetitle):
        return pagetitle in self.driver.title

    # 打开页面，并校验页面链接是否加载正确
    # 以单下划线_开头的方法，在使用import *时，该方法不会被导入，保证该方法为类私有的。
    def _open(self, url):
        # 使用get打开访问链接地址
        self.driver.get(url)
        # sleep(6)#防止出现广告，等待广告消失
        self.driver.maximize_window()

    # 定义open方法，调用_open()进行打开链接
    def open(self):
        self._open(self.base_url)

    # 重写元素定位方法
    # def find_element(self, *loc):
    #     #        return self.driver.find_element(*loc)
    #     try:
    #         # 确保元素是可见的。
    #         # 注意：以下入参为元组的元素，需要加*。Python存在这种特性，就是将入参放在元组里。
    #         #            WebDriverWait(self.driver,10).until(lambda driver: driver.find_element(*loc).is_displayed())
    #         # 注意：以下入参本身是元组，不需要加*
    #         WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located(loc))
    #         return self.driver.find_element(*loc)
    #     except:
    #         print(u"%s 页面中未能找到 %s 元素" % (self, loc))

    # 重写switch_frame方法
    def switch_frame(self, loc):
        return self.driver.switch_to_frame(loc)

    # 定义script方法，用于执行js脚本，范围执行结果
    def script(self, src):
        self.driver.execute_script(src)

    # 重写定义send_keys方法
    def send_keys(self, loc, vaule, clear_first=True, click_first=True):
        try:
            loc = getattr(self, "_%s" % loc)  # getattr相当于实现self.loc
            if click_first:
                self.find_element(*loc).click()
            if clear_first:
                self.find_element(*loc).clear()
                self.find_element(*loc).send_keys(vaule)
        except AttributeError:
            print(u"%s 页面中未能找到 %s 元素" % (self, loc))
    # 打开网页


    def click_by_link_text(self,locators):
        element = self.driver.find_element_by_partial_link_text(locators)
        element.click()
    def switch_to_window_now(self):
        '''切换到最新打开的窗口'''
        windows = self.driver.window_handles
        self.driver.switch_to.window(windows[-1])
        sleep(2)
    def click(self,element):
        # type == dict.get('type','id')
        # locators == dict['locators']
        select_type = element.get('type','id')
        select_value = element.get('locators','locators')
        if select_type == 'link_text':
            element = self.driver.find_element_by_partial_link_text(select_value)
            element.click()
        elif select_type =='id':
            element = self.driver.find_element_by_id(select_value)
            element.click()
        elif select_type =='css_selector':
            element = self.driver.find_element_by_css_selector(select_value)
            element.click()
        # 当classname中存在空格的时候，直接使用find_elementsby_class_name时，会显示定位失败，此时需要将classname中的空格替换为英文的点：‘.’
        elif select_type =='class_name':
            element = self.driver.find_element_by_class_name(select_value)
            element.click()
        elif select_type =='tag_name':
            element = self.driver.find_element_by_tag_name(select_value)
            element.click()
        elif select_type =='xpath':
            element = self.driver.find_element_by_xpath(select_value)
            element.click()
        elif select_type =='partial_link_text':
            element = self.driver.find_elements_by_partial_link_text(select_value)
            element.click()

    def ifExists(self,element):
        select_type = element.get('type','id')
        select_value = element.get('locators','locators')
        flag = True
        if select_type == 'link_text':
            try:
                ele = self.driver.find_elements_by_partial_link_text(select_value)
                return flag
            except:
                flag = False
                return flag
        elif select_type =='id':
            try:
                ele = self.driver.find_elements_by_id(select_value)
                return flag
            except:
                flag = False
                return flag
        elif select_type == 'css_selector':
            try:
                ele = self.driver.find_element_by_css_selector(select_value)
                return flag
            except:
                flag = False
                return flag
        elif select_type == 'class_name':
            try:
                ele = self.driver.find_element_by_class_name(select_value)
                return flag
            except:
                flag = False
                return flag
        elif select_type == 'tag_name':
            try:
                ele = self.driver.find_elements_by_tag_name(select_value)
                return flag
            except:
                flag = False
                return flag
        elif select_type == 'xpath':
            try:
                ele = self.driver.find_element_by_xpath(select_value)
                return flag
            except:
                flag = False
                return flag
        elif select_type == 'partial_link_text':
            try:
                ele = self.driver.find_elements_by_partial_link_text(select_value)
                return flag
            except:
                flag = False
                return flag

    def read_data(self,cell1,cell2):
    # 打开文件
        workBook = xlrd2.open_workbook('../data/baidu_data.xls')
    # 按索引号获取sheet内容
        sheet_content = workBook.sheet_by_name('Sheet1')  # 获取到了sheet1的内容
    # 获取单元格内容
        self.data = sheet_content.cell(cell1, cell2).value
        return self.data
    def input(self,element,text):
        select_type = element.get('type','id')
        select_value = element.get('locators','locators')
        if select_type == 'link_text':
            element = self.driver.find_element_by_partial_link_text(select_value)
            element.send_keys(text)
        elif select_type =='id':
            element = self.driver.find_element_by_id(select_value)
            element.send_keys(text)
        elif select_type =='css_selector':
            element = self.driver.find_element_by_css_selector(select_value)
            element.send_keys(text)
        # 当classname中存在空格的时候，直接使用find_elementsby_class_name时，会显示定位失败，此时需要将classname中的空格替换为英文的点：‘.’
        elif select_type =='class_name':
            element = self.driver.find_element_by_class_name(select_value)
            element.send_keys(text)
        elif select_type =='tag_name':
            element = self.driver.find_element_by_tag_name(select_value)
            element.send_keys(text)
        elif select_type =='xpath':
            element = self.driver.find_element_by_xpath(select_value)
            element.send_keys(text)
        elif select_type =='partial_link_text':
            element = self.driver.find_elements_by_partial_link_text(select_value)
            element.send_keys(text)


    def find_element(self,element):
        select_type = element.get('type','id')
        select_value = element.get('locators','locators')
        if select_type == 'link_text':
            element = self.driver.find_element_by_partial_link_text(select_value)
            return element
        elif select_type =='id':
            element = self.driver.find_element_by_id(select_value)
            return element
        elif select_type =='css_selector':
            element = self.driver.find_element_by_css_selector(select_value)
            return element
        # 当classname中存在空格的时候，直接使用find_elementsby_class_name时，会显示定位失败，此时需要将classname中的空格替换为英文的点：‘.’
        elif select_type =='class_name':
            element = self.driver.find_element_by_class_name(select_value)
            return element
        elif select_type =='tag_name':
            element = self.driver.find_element_by_tag_name(select_value)
            return element
        elif select_type =='xpath':
            element = self.driver.find_element_by_xpath(select_value)
            return element
        elif select_type =='partial_link_text':
            element = self.driver.find_elements_by_partial_link_text(select_value)
            return element

    def Enter(self,element):
        select_type = element.get('type', 'id')
        select_value = element.get('locators', 'locators')
        if select_type == 'link_text':
            element = self.driver.find_element_by_partial_link_text(select_value)
            element.send_keys(Keys.ENTER)
        elif select_type == 'id':
            element = self.driver.find_element_by_id(select_value)
            element.send_keys(Keys.ENTER)
        elif select_type == 'css_selector':
            element = self.driver.find_element_by_css_selector(select_value)
            element.send_keys(Keys.ENTER)
        # 当classname中存在空格的时候，直接使用find_elementsby_class_name时，会显示定位失败，此时需要将classname中的空格替换为英文的点：‘.’
        elif select_type == 'class_name':
            element = self.driver.find_element_by_class_name(select_value)
            element.send_keys(Keys.ENTER)
        elif select_type == 'tag_name':
            element = self.driver.find_element_by_tag_name(select_value)
            element.send_keys(Keys.ENTER)
        elif select_type == 'xpath':
            element = self.driver.find_element_by_xpath(select_value)
            element.send_keys(Keys.ENTER)
        elif select_type == 'partial_link_text':
            element = self.driver.find_elements_by_partial_link_text(select_value)
            element.send_keys(Keys.ENTER)

    def page_down(self):
        self.driver.find_element_by_id('upquery').send_keys(Keys.PAGE_DOWN)
    def slidespage_down(self,element):
        select_type = element.get('type', 'id')
        select_value = element.get('locators', 'locators')
        if select_type == 'link_text':
            element = self.driver.find_element_by_partial_link_text(select_value)
            element.send_keys(Keys.PAGE_DOWN)
        elif select_type == 'id':
            element = self.driver.find_element_by_id(select_value)
            element.send_keys(Keys.PAGE_DOWN)
        elif select_type == 'css_selector':
            element = self.driver.find_element_by_css_selector(select_value)
            element.send_keys(Keys.PAGE_DOWN)
        # 当classname中存在空格的时候，直接使用find_elementsby_class_name时，会显示定位失败，此时需要将classname中的空格替换为英文的点：‘.’
        elif select_type == 'class_name':
            element = self.driver.find_element_by_class_name(select_value)
            element.send_keys(Keys.PAGE_DOWN)
        elif select_type == 'tag_name':
            element = self.driver.find_element_by_tag_name(select_value)
            element.send_keys(Keys.PAGE_DOWN)
        elif select_type == 'xpath':
            element = self.driver.find_element_by_xpath(select_value)
            element.send_keys(Keys.PAGE_DOWN)
        elif select_type == 'partial_link_text':
            element = self.driver.find_elements_by_partial_link_text(select_value)
            element.send_keys(Keys.PAGE_DOWN)
