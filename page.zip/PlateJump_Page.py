# coding=utf-8
'''
此Page用于存储页面跳转所用到的页面元素信息以及方法
'''
from selenium.webdriver.common.by import By
from page.BasePage import BasePage

# 继承BasePage类
class PlateJumpPage(BasePage):
    #新闻
    news = {'type': 'link_text', 'locators': '新闻'}
    #军事
    military = {'type': 'link_text', 'locators': '军事'}
    #专题
    special = {'type': 'link_text', 'locators': '专题'}
    #体育
    sport= {'type': 'link_text', 'locators': '体育'}
    NBA = {'type': 'link_text', 'locators': 'NBA'}
    CBA = {'type': 'link_text', 'locators': 'CBA'}
    #娱乐
    entertainment= {'type': 'link_text', 'locators': '娱乐'}
    #视频
    video= {'type': 'link_text', 'locators': '视频'}
    #电视剧
    TVplay= {'type': 'link_text', 'locators': '电视剧'}
    #时尚
    fashion = {'type': 'link_text', 'locators': '时尚'}
    #旅游
    Travel= {'type': 'link_text', 'locators': '旅游'}
    #母婴
    Mother_and_baby= {'type': 'link_text', 'locators': '母婴'}
    #美食
    delicious_food= {'type': 'link_text', 'locators': '美食'}
    #文化
    Culture= {'type': 'link_text', 'locators': '文化'}
    #历史
    history= {'type': 'link_text', 'locators': '历史'}
    #邮箱
    mailbox= {'type': 'link_text', 'locators': '邮箱'}
    # mailbox = {'type': 'partial_link_text', 'locators': 'https://mail.sohu.com/?spm=smpc.home.top-nav.31.1616311355747h4Ln5cr'}
    #浏览器
    browser= {'type': 'link_text', 'locators': '浏览器'}
    #博客
    Blog= {'type': 'link_text', 'locators': '博客'}
    #千帆
    Thousandsails= {'type': 'link_text', 'locators': '千帆'}
    #微门户
    Micro_portal= {'type': 'link_text', 'locators': '微门户'}
    #公益
    public_welfare= {'type': 'link_text', 'locators': '公益'}
    #财经
    Finance_and_Economics= {'type': 'link_text', 'locators': '财经'}
    #宏观
    macroscopic= {'type': 'link_text', 'locators': '宏观'}
    #理财
    conduct_financial_transactions= {'type': 'link_text', 'locators': '理财'}
    #房产
    house_property= {'type': 'link_text', 'locators': '房产'}
    #新房
    new_house= {'type': 'link_text', 'locators': '新房'}
    #家居
    Home_Furnishing= {'type': 'link_text', 'locators': '家居'}
    #汽车
    cars= {'type': 'link_text', 'locators': '汽车'}
    #买车
    buy_car= {'type': 'link_text', 'locators': '买车'}
    #新能源
    new_energy= {'type': 'link_text', 'locators': '新能源'}
    #科技
    science_and_technology= {'type': 'link_text', 'locators': '科技'}
    #教育
    education= {'type': 'link_text', 'locators': '教育'}
    #健康
    healthy= {'type': 'link_text', 'locators': '健康'}
    #星座
    constellation= {'type': 'link_text', 'locators': '星座'}
    #动漫
    comic= {'type': 'link_text', 'locators': '动漫'}
    #游戏
    game= {'type': 'link_text', 'locators': '游戏'}
    #地图
    map= {'type': 'link_text', 'locators': '地图'}
    #输入法
    typewriting= {'type': 'link_text', 'locators': '输入法'}
    #彩票
    lottery= {'type': 'link_text', 'locators': '彩票'}
    #畅游
    Enjoy_yourself= {'type': 'link_text', 'locators': '畅游'}
    #173173游戏门户
    game17173= {'type': 'link_text', 'locators': '17173'}
    #政务
    government_affairs= {'type': 'link_text', 'locators': '政务'}


