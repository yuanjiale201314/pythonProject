# coding=utf-8
'''
此Page用于存储页搜索功能所用到的页面元素信息以及方法
'''

from page.BasePage import BasePage

# 继承BasePage类
class Search_Page(BasePage):
    #搜索输入框
    #当classname中存在空格的时候，直接使用find_elementsby_class_name时，会显示定位失败，此时需要将classname中的空格替换为英文的点：‘.’
    search_input = {'type': 'class_name', 'locators': 'search-input.left'}
    # 搜索确认按钮
    search_enter = {'type': 'class_name', 'locators': 'search-btn'}
    #搜索结果条数
    Number_of_articles = {'type': 'class_name', 'locators': 'num-tips'}
    #搜索结果时间筛选按钮
    All_time = {'type': 'class_name', 'locators': 'all - time'}
    # 筛选一天内
    One_day_select = {'type': 'link_text', 'locators': '一天内'}
    #筛选一天内全部时间
    All_time_selects = {'type': 'link_text', 'locators': '全部时间'}
    #取消筛选
    Unfilter = {'type': 'link_text', 'locators': '取消筛选'}
    #相关推荐
    Related_recommendations = {'type': 'link_text', 'locators': '相关推荐：'}
    #相关推荐结果
    Related_recommendations_result = {'type': 'link_text', 'locators': '自动化测试工具'}
    # 相关搜索
    Related_search = {'type': 'link_text', 'locators': '相关搜索'}
    # 相关搜索
    Related_search_result = {'type': 'link_text', 'locators': '软件测试工程师'}
    # 下一页
    next_page = {'type': 'link_text', 'locators': '下一页'}
    # 上一页
    previous_page = {'type': 'link_text', 'locators': '上一页'}
    # 第三页
    page_three = {'type': 'id', 'locators': 'sogou_page_3'}
    # 搜索按钮
    search_button = {'type': 'id', 'locators': 'searchBtn'}

    # error搜索按钮
    search_enter1 = {'type': 'id', 'locators': 'searchBtn1'}