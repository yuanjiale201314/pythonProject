# coding=utf-8
'''
搜狐页面基本操作方法
'''
from selenium.webdriver.common.by import By
from page.BasePage import BasePage
from selenium import webdriver

# 继承BasePage类
class SohuPage(BasePage):
    driver = webdriver.Chrome()
    # 定位器，通过元素属性定位元素对象
    username_loc = (By.NAME, 'email')

    span_loc = (By.CSS_SELECTOR, "div.error-tt>p")
    search_word = (By.ID, 'kw')
    search_done = (By.ID, 'su')
    # 操作
    # 通过继承覆盖（Overriding）方法：如果子类和父类的方法名相同，优先用子类自己的方法。
    # 打开网页
    def open(self):
        # 调用page中的_open打开连接
        self._open(self.base_url)


    # 输入用户名：调用send_keys对象，输入用户名
    def input_username(self, username):
        #        self.find_element(*self.username_loc).clear()
        self.find_element(*self.username_loc).send_keys(username)

    # 用户名或密码不合理是Tip框内容展示
    def show_span(self):
        return self.find_element(*self.span_loc).text

    # 登录成功页面中的用户ID查找
    def show_userid(self):
        return self.find_element(*self.userid_loc).text

    def click_submit(self):
        self.find_element(*self.submit_loc).click()

    def sendKeys(self, locator, text):
        try:
            # self.find_element(locator).send_keys(text)
            self.driver.find_element(locator).send_keys(text)
        except:
            print(f"输入 {text} 失败")
        # driver.find_element(By.ID, "kw")


