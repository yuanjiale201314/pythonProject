# coding=utf-8
import unittest
from selenium import webdriver
from page.BasePage import BasePage
from time import sleep
from page.PlateJump_Page import *
from page.Search_Page import Search_Page
import config

class Test_Search(unittest.TestCase):
    """
            页面跳转模块case
    """

    def setUp(self):
        self.driver = webdriver.Chrome()
        # self.driver =config.browser
        self.driver.implicitly_wait(10)
        # self.url = "http://sohu.com"
        self.url = config.test_url

    # 用例执行体
    def test_search_Push_news(self):
        base_page = BasePage(self.driver, self.url)
        # 调用打开页面组件
        base_page.open()
        # base_page.click(Search_Page.search_input)
        base_page.click(Search_Page.search_enter)
        sleep(5)
        base_page.switch_to_window_now()
        self.assertNotEqual(self.driver.title,'搜狗搜索引擎 - 上网从搜狗开始')
    def test_search_No_Push_news(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(Search_Page.search_input)
        base_page.click(Search_Page.search_enter)
        sleep(5)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title,'搜狗搜索引擎 - 上网从搜狗开始')
    def test_search_Chinese(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(Search_Page.search_input)
        base_page.input(Search_Page.search_input,'自动化测试')
        base_page.click(Search_Page.search_enter)
        sleep(5)
        base_page.switch_to_window_now()
        # self.assertEqual(self.driver.title,'自动化测试 - 搜狗搜索')
        self.assertEqual(self.driver.title,'%s - 搜狗搜索'%'自动化测试')

    def test_search_Chinese_Enter(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(Search_Page.search_input)
        base_page.input(Search_Page.search_input,'English')
        base_page.Enter(Search_Page.search_input)
        sleep(5)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title,'English - 搜狗搜索')
    def test_search_English(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(Search_Page.search_input)
        base_page.input(Search_Page.search_input,'9527')
        base_page.click(Search_Page.search_enter)
        sleep(5)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title,'%s - 搜狗搜索'%'9527')
    def test_search_English_Enter(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(Search_Page.search_input)
        base_page.input(Search_Page.search_input,'9527')
        base_page.Enter(Search_Page.search_input)
        sleep(5)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title,'%s - 搜狗搜索'%'9527')
    def test_search_Number(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(Search_Page.search_input)
        # base_page.input(Search_Page.search_input,base_page.read_data(3,0))#搜索内容存于xls文件中
        base_page.input(Search_Page.search_input,'9527')
        base_page.click(Search_Page.search_enter)
        sleep(5)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title,'%s - 搜狗搜索'%'9527')
    def test_search_Number_Enter(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(Search_Page.search_input)
        base_page.input(Search_Page.search_input,'9527')
        base_page.Enter(Search_Page.search_input)
        sleep(5)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title,'%s - 搜狗搜索'%'9527')
    def test_search_Symbol(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(Search_Page.search_input)
        base_page.input(Search_Page.search_input,'!@#$%')
        base_page.click(Search_Page.search_enter)
        sleep(5)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title,'%s - 搜狗搜索'%'!@#$%')
    def test_search_Symbol_Enter(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(Search_Page.search_input)
        base_page.input(Search_Page.search_input,'!@#$%')
        base_page.Enter(Search_Page.search_input)
        sleep(5)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title,'%s - 搜狗搜索'%'!@#$%')
    def test_search_long_text(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(Search_Page.search_input)
        base_page.input(Search_Page.search_input,'太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了')#搜索内容存于xls文件中
        base_page.click(Search_Page.search_enter)
        sleep(5)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title,'%s - 搜狗搜索'%'太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了')
    def test_search_long_text_Enter(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(Search_Page.search_input)
        base_page.input(Search_Page.search_input,'太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了')#搜索内容存于xls文件中
        base_page.Enter(Search_Page.search_input)
        sleep(5)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title,'%s - 搜狗搜索'%'太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了太长了')
    def test_search_complex_text(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(Search_Page.search_input)
        base_page.input(Search_Page.search_input,'中文English9527!@#$')
        base_page.click(Search_Page.search_enter)
        sleep(5)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title,'%s - 搜狗搜索'%'中文English9527!@#$')
    def test_search_complex_text_Enter(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(Search_Page.search_input)
        base_page.input(Search_Page.search_input,'中文English9527!@#$')
        base_page.Enter(Search_Page.search_input)
        sleep(5)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title,'%s - 搜狗搜索'%'中文English9527!@#$')
    def test_Number_of_articles(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(Search_Page.search_enter)
        sleep(5)
        base_page.switch_to_window_now()
        base_page.ifExists(Search_Page.Number_of_articles)
    def test_All_time(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(Search_Page.search_enter)
        sleep(5)
        base_page.switch_to_window_now()
        base_page.ifExists(Search_Page.All_time)
    def test_Select_All_time(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(Search_Page.search_enter)
        sleep(5)
        base_page.switch_to_window_now()
        base_page.click(Search_Page.All_time_selects)
        sleep(3)
        base_page.click(Search_Page.One_day_select)
        sleep(3)
        base_page.ifExists(Search_Page.One_day_select)

    def test_Related_recommendations(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.input(Search_Page.search_input,'自动化测试')
        base_page.click(Search_Page.search_enter)
        sleep(5)
        base_page.switch_to_window_now()
        base_page.ifExists(Search_Page.Related_recommendations)
        base_page.ifExists(Search_Page.Related_recommendations_result)
        base_page.click(Search_Page.All_time_selects)
        sleep(3)
        base_page.click(Search_Page.One_day_select)
        sleep(3)
        base_page.click(Search_Page.Unfilter)
        sleep(3)
        base_page.ifExists(Search_Page.All_time_selects)
        base_page.click(Search_Page.Related_recommendations_result)
        base_page.switch_to_window_now()
        sleep(3)
        self.assertEqual(self.driver.title,'%s - 搜狗搜索'%'自动化测试工具')

    def test_about_search(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.input(Search_Page.search_input,'测试')
        base_page.click(Search_Page.search_enter)
        sleep(5)
        base_page.switch_to_window_now()
        base_page.page_down()
        base_page.page_down()
        base_page.page_down()
        sleep(3)
        base_page.ifExists(Search_Page.Related_search)

    def test_search_page(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.input(Search_Page.search_input,'测试')
        base_page.click(Search_Page.search_enter)
        sleep(5)
        base_page.switch_to_window_now()
        base_page.page_down()
        base_page.page_down()
        base_page.page_down()
        sleep(3)
        base_page.ifExists(Search_Page.next_page)
        base_page.click(Search_Page.next_page)
        sleep(5)
        base_page.switch_to_window_now()
        base_page.page_down()
        base_page.page_down()
        base_page.page_down()
        base_page.ifExists(Search_Page.previous_page)
        base_page.ifExists(Search_Page.page_three)
        base_page.click(Search_Page.page_three)
        sleep(5)
        base_page.switch_to_window_now()
        base_page.ifExists(Search_Page.search_button)

    def tearDown(self):
        self.driver.quit()

if __name__ == "__main__":
    unittest.main()