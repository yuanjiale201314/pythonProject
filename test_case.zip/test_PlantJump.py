# coding=utf-8
import unittest
from selenium import webdriver
from page.BasePage import BasePage
from time import sleep
from page.PlateJump_Page import *
import config
class Test_PlantJump(unittest.TestCase):
    """
            页面跳转模块case
    """
    # @classmethod
    # def setUpClass(self):
    #     self.driver = webdriver.Chrome()
    #     # self.driver =config.browser
    #     self.driver.implicitly_wait(10)
    #     # self.url = "http://sohu.com"
    #     self.url = config.test_url
    def setUp(self):
        self.driver = webdriver.Chrome()
        # self.driver =config.browser
        self.driver.implicitly_wait(10)
        # self.url = "http://sohu.com"
        self.url = config.test_url

    # 用例执行体
    def test_open_news(self):
        base_page = BasePage(self.driver, self.url)
        # 调用打开页面组件
        base_page.open()
        base_page.click(PlateJumpPage.news)
        sleep(5)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title, '搜狐新闻-搜狐')
    def test_open_military(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(PlateJumpPage.military)
        sleep(5)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title, '搜狐军事-搜狐')
    def test_open_special(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(PlateJumpPage.special)
        sleep(3)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title, '搜狐专题-搜狐')
    def test_open_sport(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(PlateJumpPage.sport)
        sleep(3)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title, '体育首页-搜狐')
    def test_open_NBA(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(PlateJumpPage.NBA)
        sleep(3)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title, 'NBA-体育-搜狐')
    def test_open_CBA(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(PlateJumpPage.CBA)
        sleep(3)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title, 'CBA-体育-搜狐')
    def test_open_entertainment(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(PlateJumpPage.entertainment)
        sleep(3)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title, '搜狐娱乐-搜狐')

    def test_open_video(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(PlateJumpPage.video)
        sleep(3)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title, '搜狐视频-中国领先的综合视频网站,正版高清视频在线观看,原创视频上传,全网视频搜索')

    def test_open_TVplay(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(PlateJumpPage.TVplay)
        sleep(3)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title, '搜狐电视剧频道 - 搜狐视频')
    def test_open_fashion(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(PlateJumpPage.fashion)
        sleep(3)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title, '搜狐时尚-搜狐')

    def test_open_Travel(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(PlateJumpPage.Travel)
        sleep(3)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title, '搜狐旅游-搜狐')
    def test_open_Mother_and_baby(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(PlateJumpPage.Mother_and_baby)
        sleep(3)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title, '搜狐母婴-搜狐')
    def test_open_delicious_food(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(PlateJumpPage.delicious_food)
        sleep(3)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title, '搜狐美食-搜狐')
    def test_open_Culture(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(PlateJumpPage.Culture)
        sleep(3)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title, '搜狐文化-搜狐')
    def test_open_history(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(PlateJumpPage.history)
        sleep(3)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title, '搜狐历史-搜狐')
    # def test_open_mailbox(self):
    #     base_page = BasePage(self.driver, self.url)
    #     base_page.open()
    #     base_page.click(PlateJumpPage.mailbox)
    #     sleep(3)
    #     base_page.switch_to_window_now()
    #     self.assertEqual(self.driver.title, '搜狐闪电邮箱')
    def test_open_browser(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(PlateJumpPage.browser)
        sleep(3)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title, '搜狗高速浏览器-带您开启迅捷之旅')
    def test_open_Blog(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(PlateJumpPage.Blog)
        sleep(3)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title, '搜狐博客首页-搜狐')
    def test_open_Thousandsails(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(PlateJumpPage.Thousandsails)
        sleep(3)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title, '首页 - 搜狐千帆直播 - 搜狐旗下直播平台')
    def test_open_Micro_portal(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(PlateJumpPage.Micro_portal)
        sleep(3)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title, '搜狐网站')
    def test_open_public_welfare(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(PlateJumpPage.public_welfare)
        sleep(3)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title, '搜狐公益-搜狐')
    def test_open_Finance_and_Economics(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(PlateJumpPage.Finance_and_Economics)
        sleep(3)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title, '搜狐财经-搜狐')
    def test_open_macroscopic(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(PlateJumpPage.macroscopic)
        sleep(3)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title, '宏观')
    def test_open_conduct_financial_transactions(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(PlateJumpPage.conduct_financial_transactions)
        sleep(3)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title, '金融理财')
    def test_open_house_property(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(PlateJumpPage.house_property)
        sleep(3)
        base_page.switch_to_window_now()
        # self.assertEqual(self.driver.title, '成都房地产_成都房产网_成都房产信息网-成都搜狐焦点网')
        self.assertIn('房地产',self.driver.title)

    def test_open_new_house(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(PlateJumpPage.new_house)
        sleep(3)
        base_page.switch_to_window_now()
        # self.assertEqual(self.driver.title, '成都楼盘_成都新楼盘_成都新房-成都搜狐焦点网')
        self.assertIn('新房',self.driver.title)

    def test_open_Home_Furnishing(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(PlateJumpPage.Home_Furnishing)
        sleep(3)
        base_page.switch_to_window_now()
        # self.assertEqual(self.driver.title, '成都搜狐焦点家居-家居装修装饰品质领先平台')
        self.assertIn('家居装修装饰品质领先平台',self.driver.title)
    def test_open_cars(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(PlateJumpPage.cars)
        sleep(3)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title, '搜狐汽车_专注车.只为你')
    def test_open_buy_car(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(PlateJumpPage.buy_car)
        sleep(3)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title, '搜狐汽车_我的汽车网站，我的搜狐汽车')
    def test_open_new_energy(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(PlateJumpPage.new_energy)
        sleep(3)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title, '【新能源汽车|新能源电动汽车|纯电动汽车】_新能源_搜狐汽车')
    def test_open_science_and_technology(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(PlateJumpPage.science_and_technology)
        sleep(3)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title, '搜狐科技-搜狐')
    def test_open_education(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(PlateJumpPage.education)
        sleep(3)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title, '搜狐教育-搜狐')
    def test_open_healthy(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(PlateJumpPage.healthy)
        sleep(3)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title, '搜狐健康-搜狐')
    def test_open_constellation(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(PlateJumpPage.constellation)
        sleep(3)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title, '搜狐星座-搜狐')
    def test_open_comic(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(PlateJumpPage.comic)
        sleep(3)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title, '搜狐动漫-搜狐')
    def test_open_game(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(PlateJumpPage.game)
        sleep(3)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title, '搜狐游戏-搜狐')
    def test_open_map(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(PlateJumpPage.map)
        sleep(3)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title, '搜狗地图')
    def test_open_typewriting(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(PlateJumpPage.typewriting)
        sleep(3)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title, '搜狗输入法 - 首页')
    def test_open_lottery(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(PlateJumpPage.lottery)
        sleep(3)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title, '彩票-搜狐')
    def test_open_Enjoy_yourself(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(PlateJumpPage.Enjoy_yourself)
        sleep(3)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title, '畅游-ChangYou.com')
    def test_open_game17173(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(PlateJumpPage.game17173)
        sleep(3)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title, '::17173.com::中国游戏门户站')


    def test_open_government_affairs(self):
        base_page = BasePage(self.driver, self.url)
        base_page.open()
        base_page.click(PlateJumpPage.government_affairs)
        sleep(3)
        base_page.switch_to_window_now()
        self.assertEqual(self.driver.title, '搜狐政务-搜狐')


    def tearDown(self):
        self.driver.quit()

if __name__ == "__main__":
    unittest.main()